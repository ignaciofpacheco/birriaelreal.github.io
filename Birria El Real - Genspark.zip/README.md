# 🌮 Birria El Real - Landing Page

Una landing page de alta conversión para un negocio de tacos de birria estilo Tijuana ubicado en Mazatlán, diseñada para maximizar los pedidos a través de WhatsApp.

![Birria El Real](https://www.genspark.ai/api/files/s/2rbCFxcS)

## 🎯 Objetivo del Proyecto

Crear una web de alta conversión enfocada en captar pedidos exclusivamente a través de WhatsApp, con un diseño moderno, atractivo y que destaque la propuesta de valor única: **receta estilo Tijuana que no encontrarás en otro lugar de Mazatlán**.

## ✅ Características Implementadas

### Secciones de la Página

1. **Hero Section**
   - Logo destacado con animación flotante
   - Título impactante "LA BIRRIA que te hará volver"
   - Texto descriptivo con efecto de iluminación sutil (glow)
   - CTAs principales a WhatsApp (Ver Menú / Ordenar Ahora)
   - Badges informativos (100% Artesanal, Receta Estilo Tijuana, +500 Clientes Felices)
   - Indicador "Descubre más" separado con fondo semitransparente

2. **Nuestras Especialidades** (Solo 2 productos)
   - Tacos de Birria (producto estrella)
   - Raciones de Birria (con consomé incluido)
   - Sin precios visibles - Consulta por WhatsApp
   - Cada tarjeta incluye imagen, descripción y CTA a WhatsApp

3. **¡Sabor que Enamora! (Galería)**
   - Grid de imágenes responsive con fotos reales de tacos de birria
   - Efecto hover con overlay
   - CTA central para ordenar

4. **Beneficios**
   - Sabor Artesanal (receta estilo Tijuana)
   - Consomé Explosivo (preparado con chiles secos seleccionados)
   - Siempre Fresco (preparación al momento)

5. **Opiniones de Clientes**
   - 3 testimonios con estrellas
   - Imágenes de referencia de los pedidos
   - Sin referencias a productos que no se sirven

6. **CTA Final**
   - Logo destacado
   - Llamado a la acción principal
   - Botón grande de WhatsApp
   - Solo dirección (Avenida Prados del Sol, Mazatlán)

7. **Footer Simplificado**
   - Logo y descripción
   - Enlaces de navegación
   - Solo dirección - Sin teléfono, email ni redes sociales
   - CTA de WhatsApp

### Elementos de Conversión

- **Botón flotante de WhatsApp** - Siempre visible con animación de pulso
- **Múltiples CTAs a WhatsApp** - En cada sección estratégica
- **Mensajes pre-escritos** - Cada enlace incluye un mensaje personalizado
- **Sin precios visibles** - Toda consulta se hace por WhatsApp
- **Propuesta de valor clara** - Receta estilo Tijuana única en Mazatlán
- **Testimonios sociales** - Prueba social con reseñas 5 estrellas

### Características Técnicas

- ✅ **Diseño 100% Responsive** - Adaptado para móvil, tablet y escritorio
- ✅ **Animaciones AOS** - Efectos de aparición al hacer scroll
- ✅ **Navegación sticky** - Header fijo con efecto de scroll
- ✅ **Lazy loading de imágenes** - Optimización de carga
- ✅ **Smooth scrolling** - Navegación suave entre secciones
- ✅ **Menú móvil** - Navegación hamburguesa para dispositivos pequeños
- ✅ **Optimización SEO** - Meta tags y estructura semántica
- ✅ **Efecto glow** - Iluminación sutil en texto descriptivo del hero

## 📁 Estructura de Archivos

```
/
├── index.html          # Página principal
├── css/
│   └── style.css       # Estilos completos
├── js/
│   └── main.js         # JavaScript para interactividad
└── README.md           # Documentación
```

## 🔗 URIs Funcionales

| Ruta | Descripción |
|------|-------------|
| `/` o `/index.html` | Página principal |
| `/#inicio` | Sección Hero |
| `/#especialidades` | Sección de productos |
| `/#galeria` | Galería de fotos |
| `/#opiniones` | Testimonios |

## 📱 Enlaces de WhatsApp

Todos los CTAs dirigen a WhatsApp con mensajes personalizados:

- **Menú**: "¡Hola! Quiero ver el menú de Birria El Real"
- **Ordenar**: "¡Hola! Quiero hacer un pedido de Birria El Real"
- **Tacos**: "¡Hola! Quiero ordenar Tacos de Birria"
- **Raciones**: "¡Hola! Quiero ordenar una Ración de Birria"

## 🎨 Paleta de Colores

| Color | Hex | Uso |
|-------|-----|-----|
| Amarillo Dorado | `#FFD700` | Color primario, CTAs, acentos |
| Rojo | `#FF4444` | Color secundario, alertas |
| Naranja | `#FF6B35` | Acentos, badges |
| Verde WhatsApp | `#25D366` | Botones de WhatsApp |
| Negro | `#0D0D0D` | Fondo principal |
| Crema | `#FFF8E7` | Fondo alternativo |

## 🔧 Tecnologías Utilizadas

- **HTML5** - Estructura semántica
- **CSS3** - Estilos y animaciones (incluyendo efecto glow)
- **JavaScript ES6+** - Interactividad
- **AOS Library** - Animaciones al scroll
- **Font Awesome 6** - Iconos
- **Google Fonts** - Tipografías (Bebas Neue, Poppins)

## 📝 Personalización

### Cambiar número de WhatsApp

Buscar y reemplazar `521234567890` por el número real del negocio en todos los archivos.

### Cambiar imágenes

Reemplazar las URLs de las imágenes por imágenes propias del negocio. Las imágenes actuales son:
- `https://www.genspark.ai/api/files/s/2rbCFxcS` - Logo
- `https://www.genspark.ai/api/files/s/Q6medNt0` - Tacos con limón
- `https://www.genspark.ai/api/files/s/6jw7QgDW` - Ración de tacos

### Cambiar dirección

Actualizar la dirección en el footer y sección CTA de `index.html`.
Dirección actual: **Avenida Prados del Sol, Mazatlán**

## 📍 Información de Contacto

- **Ubicación**: Avenida Prados del Sol, Mazatlán
- **Contacto**: Solo por WhatsApp
- **Productos**: Tacos de Birria y Raciones

## 🚀 Próximos Pasos Recomendados

1. **Reemplazar número de WhatsApp** - Usar el número real del negocio
2. **Añadir más imágenes propias** - Fotos profesionales de los productos
3. **Configurar analytics** - Google Analytics o similar
4. **Integrar Google Maps** - Mostrar ubicación exacta (opcional)

## 📊 Métricas de Conversión Sugeridas

- Clicks en botón flotante de WhatsApp
- Clicks en CTAs de productos específicos
- Tiempo en página
- Scroll depth
- Tasa de rebote

---

**Sabor artesanal estilo Tijuana en Mazatlán** 🌶️

© 2025 Birria El Real. Todos los derechos reservados.
